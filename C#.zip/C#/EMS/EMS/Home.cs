﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EMS
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void loginToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Login obj = new Login();
            obj.Show();
            this.Hide();
        }

        private void registrationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Registration obj = new Registration();
            obj.Show();
            this.Hide();
        }

        private void toolStripLabel1_Click(object sender, EventArgs e)
        {
            ColorDialog cd=new ColorDialog();
            if (cd.ShowDialog() == DialogResult.OK)
                this.BackColor = cd.Color;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string department = comboBox1.SelectedItem.ToString();
            MessageBox.Show(department);
            //if (toolStripProgressBar1.Value == 100)
            //    toolStripProgressBar1.Value = 0;
            //else
            //    toolStripProgressBar1.Value += 10;
        }

        private void buttonToolStripMenuItem_Click(object sender, EventArgs e)
        {
            button2.Text = "Changed";
        }

        private void formToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Text = "Home Page";
        }

        private void backColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            if (cd.ShowDialog() == DialogResult.OK)
                this.BackColor = cd.Color;
        }
    }
}
