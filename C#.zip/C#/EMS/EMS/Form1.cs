﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EMS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;
            string id = txtId.Text;
            string cgpa = txtCgpa.Text;
            MessageBox.Show("ID:" + id + "Name:" + name + "Cgpa:" + cgpa);
        }

        private void btnShow_MouseClick(object sender, MouseEventArgs e)
        {

        }

        private void txtId_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
