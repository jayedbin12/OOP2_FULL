﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EMS
{
    public partial class Dashboard : Form
    {
        private bool isNew = false;
        public Dashboard()
        {
            InitializeComponent();
        }

        private void Dashboard_Load(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-NJBKCUM\SQLEXPRESS;Initial Catalog=OOP2FDB;Integrated Security=True");
            conn.Open();
            string query = "select * from Employee";
            DataTable dt = LoadEmployee(query);
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();
            conn.Close(); 

        }

        private DataTable LoadEmployee(string query)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-NJBKCUM\SQLEXPRESS;Initial Catalog=OOP2FDB;Integrated Security=True");
            conn.Open();
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.ExecuteNonQuery();
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adp.Fill(ds);
            DataTable dt = ds.Tables[0];
            return dt;
            //DataTable dt2 = ds.Tables[1];

        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                int id = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
                //MessageBox.Show(id + " ");
                SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-NJBKCUM\SQLEXPRESS;Initial Catalog=OOP2FDB;Integrated Security=True");
                conn.Open();
                string query = "select * from Employee where ID="+id;
                DataTable dt = LoadEmployee(query);
                //DataTable dt2 = ds.Tables[1];
                textBox1.Text = dt.Rows[0]["ID"].ToString();
                textBox2.Text = dt.Rows[0]["Name"].ToString();
                textBox3.Text = dt.Rows[0]["Email"].ToString();
                //query = "select * from Employee";
                //dt = LoadEmployee(query);
                //dataGridView1.AutoGenerateColumns = false;
                //dataGridView1.DataSource = dt;
                //dataGridView1.Refresh();
                conn.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name, email;
            
            name = textBox2.Text;
            email = textBox3.Text;
            SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-NJBKCUM\SQLEXPRESS;Initial Catalog=OOP2FDB;Integrated Security=True");
            conn.Open();
            string query;
            if (isNew == true)
            {
                query = "insert into Employee (Name,UserName,Password,Email,Gender,Skills,DOB) values('" + name + "','" + name + "','123','" + email + "','Female','c#','8/4/1990')";
                isNew = false;
            }
            else
            {
                 int id = Convert.ToInt32(textBox1.Text);
                 query = "update Employee set Name='"+name+"', Email='"+email+"' where ID=" + id;
            }
            SqlCommand cmd = new SqlCommand(query, conn);
            int row=cmd.ExecuteNonQuery();
            if (row > 0)
            {
                MessageBox.Show("operation successful");
                query = "select * from Employee";
                cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adp.Fill(ds);
                DataTable dt = ds.Tables[0];
                //DataTable dt2 = ds.Tables[1];
                dataGridView1.AutoGenerateColumns = false;
                dataGridView1.DataSource = dt;
                dataGridView1.Refresh();
            }
            conn.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            isNew = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            string query = "select * from Employee";
            DataTable dt = LoadEmployee(query);
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.DataSource = dt;
            dataGridView1.Refresh();
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-NJBKCUM\SQLEXPRESS;Initial Catalog=OOP2FDB;Integrated Security=True");
            conn.Open();
            string query;
            int id = Convert.ToInt32(textBox1.Text);
            query = "Delete from Employee where ID="+id;
            SqlCommand cmd = new SqlCommand(query, conn);
            int row=cmd.ExecuteNonQuery();
            if (row > 0)
            {
                MessageBox.Show("operation successful");
                query = "select * from Employee";
                cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
                SqlDataAdapter adp = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adp.Fill(ds);
                DataTable dt = ds.Tables[0];
                //DataTable dt2 = ds.Tables[1];
                dataGridView1.AutoGenerateColumns = false;
                dataGridView1.DataSource = dt;
                dataGridView1.Refresh();
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
            }
            conn.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox4.Text =="")
                MessageBox.Show("Please write something to search");
            else
            {
                SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-NJBKCUM\SQLEXPRESS;Initial Catalog=OOP2FDB;Integrated Security=True");
                conn.Open();
                string query = "select * from Employee where Name like '%" + textBox4.Text + "%'";
                DataTable dt = LoadEmployee(query);
                dataGridView1.AutoGenerateColumns = false;
                dataGridView1.DataSource = dt;
                dataGridView1.Refresh();
                conn.Close();
            }
        }
            
    }
}
