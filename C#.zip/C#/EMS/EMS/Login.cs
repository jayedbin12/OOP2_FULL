﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EMS
{
    public partial class Login : Form
    {
        private string uname = "kazisadia";
        private string password = "123";
        public Login()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (uname == textBox1.Text && password == textBox2.Text){
                MessageBox.Show("Successful login");
                Home obj=new Home();
                obj.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid username or password");
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Registration obj=new Registration();
            obj.Show();
            this.Hide();
        }
    }
}
