﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EMS
{
    public partial class Calculator : Form
    {
        private int num1 = 0;
        private int num2 = 0;
        private bool flag = false;
        private char opt = ' ';
        public Calculator()
        {
            InitializeComponent();
        }

        private void btnOne_Click(object sender, EventArgs e)
        {
            if(flag==false)
              textBox1.Text += "1";
            else
            {
                textBox1.Text = "1";
                flag = false;
            }
        }

        private void btnTwo_Click(object sender, EventArgs e)
        {
            if (flag == false)
                textBox1.Text += "2";
            else
            {
                textBox1.Text = "2";
                flag = false;
            }
        }

        private void btnThree_Click(object sender, EventArgs e)
        {
            if (flag == false)
                textBox1.Text += "3";
            else
            {
                textBox1.Text = "3";
                flag = false;
            }
        }

        private void btnFour_Click(object sender, EventArgs e)
        {
            if (flag == false)
                textBox1.Text += "4";
            else
            {
                textBox1.Text = "4";
                flag = false;
            }
        }

        private void btnFive_Click(object sender, EventArgs e)
        {
            if (flag == false)
                textBox1.Text += "5";
            else
            {
                textBox1.Text = "5";
                flag = false;
            }
        }

        private void btnSix_Click(object sender, EventArgs e)
        {
            if (flag == false)
                textBox1.Text += "6";
            else
            {
                textBox1.Text = "6";
                flag = false;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            num1 = Convert.ToInt32(textBox1.Text);
            label1.Text = num1 + "+";
            flag = true;
            opt = '+';

        }

        private void btnEqual_Click(object sender, EventArgs e)
        {
            num2 = Convert.ToInt32(textBox1.Text);
            int result;
            if (opt == '+')
            {
                result = num1 + num2;
                textBox1.Text = result + " ";
                label1.Text += num2 + "=";
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            textBox1.Text = " ";
            label1.Text = " ";
        }
    }
}
