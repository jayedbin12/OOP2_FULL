﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EMS
{
    public partial class Registration : Form
    {
        public Registration()
        {
            InitializeComponent();
        }

        private void btnSignup_Click(object sender, EventArgs e)
        {
            string name, username, password, email, gender = " ", skills = " ";
            DateTime dob=Convert.ToDateTime(dateTimePicker1.Text);
            if (textBox1.Text == "" || textBox2.Text == "")
            {
                MessageBox.Show("name or username is not provided");
                return;
            }
            else
            {
                name = textBox1.Text;
                username = textBox2.Text;
            }
            
            password = textBox3.Text;
            email = textBox4.Text;
            if (checkBox1.Checked)
                skills += "Java, ";
            if (checkBox2.Checked)
                skills += "c#, ";
            if (checkBox3.Checked)
                skills += "python, ";
            if (checkBox4.Checked)
                skills += "f#";
            if (radioButton1.Checked)
            {
                //MessageBox.Show("Male");
                gender = "Male";
            }
            else if (radioButton2.Checked)
            {
                //MessageBox.Show("Female");
                gender = "Female";
            }
            else if (radioButton3.Checked)
            {
                //MessageBox.Show("Others");
                gender = "Other";
            }
            SqlConnection conn=new SqlConnection(@"Data Source=DESKTOP-NJBKCUM\SQLEXPRESS;Initial Catalog=OOP2FDB;Integrated Security=True");
            conn.Open();
            string query =
                "insert into Employee (Name,UserName,Password,Email,Gender,Skills,DOB) VALUES('"+name+"','"+username+"','"+password+"','"+email+"','"+gender+"','"+skills+"','"+dob+"')";
            SqlCommand cmd=new SqlCommand(query,conn);
            int row=cmd.ExecuteNonQuery();
            if (row > 0)
                MessageBox.Show("Successfully registered");
            
    }
}
    }
