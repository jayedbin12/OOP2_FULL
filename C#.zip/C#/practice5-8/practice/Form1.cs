﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace practice
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        override protected void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            if (e.CloseReason != CloseReason.WindowsShutDown)
            {
                Application.Exit();
            }
        }

        private static string connectionstring = @"Server=LAPTOP-35V804DV;Database=db_practice;Integrated Security=true;";
        private static SqlConnection connection = new SqlConnection(connectionstring);

        private void bttnlogin_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM practice";
            DataTable dt = new DataTable();
            string data = "";

            connection.Open();

            SqlDataAdapter dtaAdapter = new SqlDataAdapter(query, connection);
            dtaAdapter.Fill(dt);

            dgvlogin.DataSource = dt;

            connection.Close();

        }

        private void bttninsert_Click(object sender, EventArgs e)
        {
            string name = txtname.Text.Trim();
            string pass = txtpass.Text.Trim();

            if (name.Length == 0 || pass.Length == 0)
                return;

            string query = String.Format("INSERT INTO practice VALUES('{0}', '{1}');", name, pass);

            connection.Open();

            SqlCommand cmd = new SqlCommand(query, connection);
            int numberOfRowsEffect = cmd.ExecuteNonQuery();

            connection.Close();

            if (numberOfRowsEffect > 0)
                MessageBox.Show("Insert successful");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void dgvlogin_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
          
        }

        private void bttnsearch_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM practice WHERE name='" + txtsearch.Text + "'";
            DataTable dt = new DataTable();
            //string data = "";

            connection.Open();

            SqlDataAdapter dtaAdapter = new SqlDataAdapter(query, connection);
            dtaAdapter.Fill(dt);

            dgvlogin.DataSource = dt;

            connection.Close();
        }

        private void bttnedit_Click(object sender, EventArgs e)
        {
            string id = txtid.Text.Trim();
            string name = txtname.Text.Trim();
            string pass = txtpass.Text.Trim();

            if (id.Length == 0 || name.Length == 0 || pass.Length == 0)
                return;

            string query = String.Format("UPDATE practice SET name = '{0}', pass = '{1}' WHERE id = {2};", name, pass, id);

            connection.Open();

            SqlCommand cmd = new SqlCommand(query, connection);
            int numberOfRowsEffect = cmd.ExecuteNonQuery();

            connection.Close();

            if (numberOfRowsEffect > 0)
                MessageBox.Show("Edited successfully");
        }

        private void bttndelete_Click(object sender, EventArgs e)
        {
            string id = txtid.Text.Trim();

            if (id.Length == 0)
                return;

            string query = String.Format("DELETE FROM practice WHERE id = {0};", id);

            connection.Open();

            SqlCommand cmd = new SqlCommand(query, connection);
            int numberOfRowsEffect = cmd.ExecuteNonQuery();

            connection.Close();

            if (numberOfRowsEffect > 0)
                MessageBox.Show("Delete successfully");
        }

    }
}
