﻿namespace practice
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lblid = new System.Windows.Forms.Label();
            this.lblname = new System.Windows.Forms.Label();
            this.lblpass = new System.Windows.Forms.Label();
            this.txtid = new System.Windows.Forms.TextBox();
            this.txtname = new System.Windows.Forms.TextBox();
            this.txtpass = new System.Windows.Forms.TextBox();
            this.bttnlogin = new System.Windows.Forms.Button();
            this.dgvlogin = new System.Windows.Forms.DataGridView();
            this.bttninsert = new System.Windows.Forms.Button();
            this.bttnedit = new System.Windows.Forms.Button();
            this.bttndelete = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.bttnbedona = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lbljibon = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.bttnsearch = new System.Windows.Forms.Button();
            this.txtsearch = new System.Windows.Forms.TextBox();
            this.lblsearch = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvlogin)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblid
            // 
            this.lblid.AutoSize = true;
            this.lblid.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblid.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblid.Location = new System.Drawing.Point(49, 50);
            this.lblid.Name = "lblid";
            this.lblid.Size = new System.Drawing.Size(37, 31);
            this.lblid.TabIndex = 0;
            this.lblid.Text = "id";
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblname.Location = new System.Drawing.Point(49, 92);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(67, 27);
            this.lblname.TabIndex = 1;
            this.lblname.Text = "name";
            // 
            // lblpass
            // 
            this.lblpass.AutoSize = true;
            this.lblpass.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.lblpass.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpass.Location = new System.Drawing.Point(49, 134);
            this.lblpass.Name = "lblpass";
            this.lblpass.Size = new System.Drawing.Size(70, 31);
            this.lblpass.TabIndex = 2;
            this.lblpass.Text = "pass";
            // 
            // txtid
            // 
            this.txtid.Location = new System.Drawing.Point(178, 50);
            this.txtid.Name = "txtid";
            this.txtid.Size = new System.Drawing.Size(100, 22);
            this.txtid.TabIndex = 3;
            // 
            // txtname
            // 
            this.txtname.Location = new System.Drawing.Point(178, 92);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(100, 22);
            this.txtname.TabIndex = 4;
            // 
            // txtpass
            // 
            this.txtpass.Location = new System.Drawing.Point(178, 134);
            this.txtpass.Name = "txtpass";
            this.txtpass.PasswordChar = '*';
            this.txtpass.Size = new System.Drawing.Size(100, 22);
            this.txtpass.TabIndex = 5;
            // 
            // bttnlogin
            // 
            this.bttnlogin.Location = new System.Drawing.Point(126, 179);
            this.bttnlogin.Name = "bttnlogin";
            this.bttnlogin.Size = new System.Drawing.Size(194, 35);
            this.bttnlogin.TabIndex = 6;
            this.bttnlogin.Text = "login";
            this.bttnlogin.UseVisualStyleBackColor = true;
            this.bttnlogin.Click += new System.EventHandler(this.bttnlogin_Click);
            // 
            // dgvlogin
            // 
            this.dgvlogin.BackgroundColor = System.Drawing.Color.Aqua;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvlogin.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvlogin.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvlogin.GridColor = System.Drawing.SystemColors.Highlight;
            this.dgvlogin.Location = new System.Drawing.Point(427, 30);
            this.dgvlogin.Name = "dgvlogin";
            this.dgvlogin.RowTemplate.Height = 24;
            this.dgvlogin.Size = new System.Drawing.Size(471, 225);
            this.dgvlogin.TabIndex = 7;
            this.dgvlogin.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvlogin_CellContentClick);
            // 
            // bttninsert
            // 
            this.bttninsert.Location = new System.Drawing.Point(126, 237);
            this.bttninsert.Name = "bttninsert";
            this.bttninsert.Size = new System.Drawing.Size(194, 40);
            this.bttninsert.TabIndex = 8;
            this.bttninsert.Text = "Insert";
            this.bttninsert.UseVisualStyleBackColor = true;
            this.bttninsert.Click += new System.EventHandler(this.bttninsert_Click);
            // 
            // bttnedit
            // 
            this.bttnedit.Location = new System.Drawing.Point(126, 303);
            this.bttnedit.Name = "bttnedit";
            this.bttnedit.Size = new System.Drawing.Size(194, 36);
            this.bttnedit.TabIndex = 9;
            this.bttnedit.Text = "Edit";
            this.bttnedit.UseVisualStyleBackColor = true;
            this.bttnedit.Click += new System.EventHandler(this.bttnedit_Click);
            // 
            // bttndelete
            // 
            this.bttndelete.Location = new System.Drawing.Point(126, 364);
            this.bttndelete.Name = "bttndelete";
            this.bttndelete.Size = new System.Drawing.Size(194, 36);
            this.bttndelete.TabIndex = 10;
            this.bttndelete.Text = "Delete";
            this.bttndelete.UseVisualStyleBackColor = true;
            this.bttndelete.Click += new System.EventHandler(this.bttndelete_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(427, 307);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(506, 127);
            this.tabControl1.TabIndex = 11;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.bttnbedona);
            this.tabPage1.Controls.Add(this.textBox1);
            this.tabPage1.Controls.Add(this.lbljibon);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(498, 98);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // bttnbedona
            // 
            this.bttnbedona.Location = new System.Drawing.Point(220, 37);
            this.bttnbedona.Name = "bttnbedona";
            this.bttnbedona.Size = new System.Drawing.Size(75, 23);
            this.bttnbedona.TabIndex = 2;
            this.bttnbedona.Text = "bedona";
            this.bttnbedona.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(88, 32);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 22);
            this.textBox1.TabIndex = 1;
            // 
            // lbljibon
            // 
            this.lbljibon.AutoSize = true;
            this.lbljibon.Location = new System.Drawing.Point(35, 35);
            this.lbljibon.Name = "lbljibon";
            this.lbljibon.Size = new System.Drawing.Size(38, 17);
            this.lbljibon.TabIndex = 0;
            this.lbljibon.Text = "jibon";
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(498, 98);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // bttnsearch
            // 
            this.bttnsearch.Location = new System.Drawing.Point(305, 111);
            this.bttnsearch.Name = "bttnsearch";
            this.bttnsearch.Size = new System.Drawing.Size(101, 30);
            this.bttnsearch.TabIndex = 12;
            this.bttnsearch.Text = "Search";
            this.bttnsearch.UseVisualStyleBackColor = true;
            this.bttnsearch.Click += new System.EventHandler(this.bttnsearch_Click);
            // 
            // txtsearch
            // 
            this.txtsearch.Location = new System.Drawing.Point(305, 68);
            this.txtsearch.Name = "txtsearch";
            this.txtsearch.Size = new System.Drawing.Size(100, 22);
            this.txtsearch.TabIndex = 13;
            // 
            // lblsearch
            // 
            this.lblsearch.AutoSize = true;
            this.lblsearch.Location = new System.Drawing.Point(329, 30);
            this.lblsearch.Name = "lblsearch";
            this.lblsearch.Size = new System.Drawing.Size(53, 17);
            this.lblsearch.TabIndex = 14;
            this.lblsearch.Text = "Search";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1063, 446);
            this.Controls.Add(this.lblsearch);
            this.Controls.Add(this.txtsearch);
            this.Controls.Add(this.bttnsearch);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.bttndelete);
            this.Controls.Add(this.bttnedit);
            this.Controls.Add(this.bttninsert);
            this.Controls.Add(this.dgvlogin);
            this.Controls.Add(this.bttnlogin);
            this.Controls.Add(this.txtpass);
            this.Controls.Add(this.txtname);
            this.Controls.Add(this.txtid);
            this.Controls.Add(this.lblpass);
            this.Controls.Add(this.lblname);
            this.Controls.Add(this.lblid);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "login";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvlogin)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblid;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.Label lblpass;
        private System.Windows.Forms.TextBox txtid;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.TextBox txtpass;
        private System.Windows.Forms.Button bttnlogin;
        private System.Windows.Forms.DataGridView dgvlogin;
        private System.Windows.Forms.Button bttninsert;
        private System.Windows.Forms.Button bttnedit;
        private System.Windows.Forms.Button bttndelete;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button bttnbedona;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lbljibon;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button bttnsearch;
        private System.Windows.Forms.TextBox txtsearch;
        private System.Windows.Forms.Label lblsearch;
    }
}

