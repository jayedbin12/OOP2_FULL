﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DatabaseOperations
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        override protected void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            if (e.CloseReason != CloseReason.WindowsShutDown)
            {
                Application.Exit();
            }
        }

        private static string connectionstring = @"Server=LAPTOP-35V804DV;Database=db_checking;Integrated Security=true;";
        private static SqlConnection connection = new SqlConnection(connectionstring);

        private void btnShow_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM users";
            DataTable dt = new DataTable();
            string data = "";

            connection.Open();

            SqlDataAdapter dtaAdapter = new SqlDataAdapter(query, connection);
            dtaAdapter.Fill(dt);

            dgvShow.DataSource = dt;


             SqlCommand cmd = new SqlCommand(query, connection);
             SqlDataReader reader = cmd.ExecuteReader();

            //while (reader.Read())
            //{
            //    data += reader.GetInt32(reader.GetOrdinal("id")) + " " + reader.GetString(reader.GetOrdinal("name")).Trim() + " " + reader.GetString(reader.GetOrdinal("pass")).Trim() + "\n";
            //}

            connection.Close();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {
            string name = tbName.Text.Trim();
            string pass = tbPass.Text.Trim();

            if (name.Length == 0 || pass.Length == 0)
                return;

            string query = String.Format("INSERT INTO users VALUES('{0}', '{1}');", name, pass);

            connection.Open();

            SqlCommand cmd = new SqlCommand(query, connection);
            int numberOfRowsEffect = cmd.ExecuteNonQuery();

            connection.Close();

            if (numberOfRowsEffect > 0)
                MessageBox.Show("Insert successful");
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            string id = tbId.Text.Trim();
            string name = tbName.Text.Trim();
            string pass = tbPass.Text.Trim();

            if (id.Length == 0 || name.Length == 0 || pass.Length == 0)
                return;

            string query = String.Format("UPDATE users SET name = '{0}', pass = '{1}' WHERE id = {2};", name, pass, id);

            connection.Open();

            SqlCommand cmd = new SqlCommand(query, connection);
            int numberOfRowsEffect = cmd.ExecuteNonQuery();

            connection.Close();

            if (numberOfRowsEffect > 0)
                MessageBox.Show("Edited successfully");
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string id = tbId.Text.Trim();

            if (id.Length == 0)
                return;

            string query = String.Format("DELETE FROM users WHERE id = {0};", id);

            connection.Open();

            SqlCommand cmd = new SqlCommand(query, connection);
            int numberOfRowsEffect = cmd.ExecuteNonQuery();

            connection.Close();

            if (numberOfRowsEffect > 0)
                MessageBox.Show("Delete successfully");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Form2().Show();
        }

        private void dgvShow_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
